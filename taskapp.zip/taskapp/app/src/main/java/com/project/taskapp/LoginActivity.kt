package com.seuprojeto.loginapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    // Chave usada para passar o nome via Intent
    companion object {
        const val EXTRA_NOME_USUARIO = "NOME_USUARIO"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Aponta para nosso layout com boas práticas
        setContentView(R.layout.activity_login)

        // Referências para os componentes da tela
        val editTextNome = findViewById<EditText>(R.id.editTextNome)
        val buttonEntrar = findViewById<Button>(R.id.buttonEntrar)

        buttonEntrar.setOnClickListener {
            val nomeUsuario = editTextNome.text.toString().trim()
            if (nomeUsuario.isNotEmpty()) {
                // Prepara Intent para TelaInicialActivity
                val intent = Intent(this, TelaInicialActivity::class.java).apply {
                    putExtra(EXTRA_NOME_USUARIO, nomeUsuario)
                }
                startActivity(intent)
                // Finaliza a LoginActivity para não voltar por “voltar”
                finish()
            } else {
                // Mostra mensagem de erro breve
                Toast.makeText(
                    this,
                    getString(R.string.hint_nome),  // ou use outra string de aviso
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }
}
